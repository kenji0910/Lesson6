# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'b83934e152a886b57954d4069c1aad6b9e085a27cf2ece5aa2f6d9806106e9f6487f68a0f7433ffaca671e2ea12416330055ddd5f8855a5b1d1034b472cb1441'


